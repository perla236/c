#include <stdio.h>
#include <time.h>
#include <stdlib.h>
//#define MIN -2147483648
//#define MAX 2147483647
typedef struct 
{
    long uneseni_broj;
    int broj_znamenaka;
}CIJELI_BROJ;

int racun(long n)
{
    int count=0;
    do{
        n=n/10;
        count++;
    }
    while (n != 0);
    return count;
}
int main()
{   // cijeli_broj.uneseni_broj = MIN + (long)rand() / RAND_MAX * (MAX-MIN);

    
    srand( time(NULL));
    CIJELI_BROJ cijeli_broj[40];
    int temp, i, c1=0, c2=0;
    
    for(i=0; i<40; i++){
    cijeli_broj[i].uneseni_broj = rand();
    cijeli_broj[i].broj_znamenaka = racun (cijeli_broj[i].uneseni_broj);
    
    printf("%ld ",cijeli_broj[i].uneseni_broj);
    printf("\t");
    printf("%d ", cijeli_broj[i].broj_znamenaka);
     printf("\n");
    }
    
    for (i = 0; i < 40; i++)                    
	{
		for (int j = 0; j < 40; j++)            
		{
			if (cijeli_broj[j].broj_znamenaka < cijeli_broj[i].broj_znamenaka)                
			{
				int tmp = cijeli_broj[i].broj_znamenaka;         
				cijeli_broj[i].broj_znamenaka = cijeli_broj[j].broj_znamenaka;            
				cijeli_broj[j].broj_znamenaka = tmp;

                long templong = cijeli_broj[i].uneseni_broj;
                cijeli_broj[i].uneseni_broj = cijeli_broj[j].uneseni_broj;
                cijeli_broj[j].uneseni_broj=templong;             
			}
		}
	}
     printf("\nProvjera\n");
   for(i=0; i<40; i++)
   {
       printf("%d", cijeli_broj[i].broj_znamenaka);
   }
         printf("\n");
printf("Broj najvecih ");

for(i=0; i<40; i++){
    if(cijeli_broj[0].broj_znamenaka==cijeli_broj[i].broj_znamenaka)
    {
        c1++;
        printf("%d  ", c1);
    }
} printf("\n");
printf("Broj najmanjih ");
    for(i=39; i>-1; i--){
    if(cijeli_broj[39].broj_znamenaka==cijeli_broj[i].broj_znamenaka)
    {
        c2++;
        printf("%d  ", c2);
    }
}
printf("\n");
printf("Najveci clanovi");
printf("\n");
for(i=0; i<c1; i++){
    printf("Uneseni broj %ld broj znamenaka %d\n", cijeli_broj[i].uneseni_broj, cijeli_broj[i].broj_znamenaka);
}

printf("\n");
printf("Najmanji clanovi");
printf("\n");
for(i=39; i>(39-c2); i--){
    printf("Uneseni broj %ld broj znamenaka %d\n", cijeli_broj[i].uneseni_broj, cijeli_broj[i].broj_znamenaka);
}


    return 0;
}