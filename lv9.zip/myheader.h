//HEADER
#ifndef MYHEADER
    #define MYHEADER
    
    
    int linearnoPretrazivanje(int polje[], int *koraci, int n, int *index);
    
    
    
#endif