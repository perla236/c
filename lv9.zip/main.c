//MAIN
#include <stdio.h>
#include "myheader.h"
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>




int main()
{
    int polje[500];
    int index;
    int koraci;
    int n;
    int i;
     
FILE *fp = NULL;
const char *imeDatoteke = "dat.txt";

fp = fopen(imeDatoteke, "w");

if (fp == NULL) {
printf("Datoteka %s ne postoji na disku.\n", imeDatoteke);
}
else {
printf("Datoteka %s postoji na disku.\n", imeDatoteke);
fclose(fp);
}

    for (i=0; i<500; i++){
        polje[i]= rand() % (1000 + 1 - 0) + 0;
    }
   
   fp= fopen(imeDatoteke, "w+");
   for (i=0; i<500; i++){
   fprintf(fp, "%d ", polje[i]);
   }
   fclose(fp);
    printf("Unesi trazeni broj");
    scanf("%d", &n);
    
    linearnoPretrazivanje(polje, &koraci, n, &index);
    
    printf("\nBroj %d je pronadjen nakon %d koraka na indeksu %d.", n, koraci, index);
    return 0;
}
