#include <stdio.h>
#include "myheader.h"
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>



int linearnoPretrazivanje(int polje[], int *koraci, int n, int *index)
{   int koracitemp=0;
    for (int i = 0; i < 500; i++)
    {
koracitemp++;

if (polje[i] == n) {
*koraci = koracitemp;
*index=i;
}
}
return -1;
}