#ifndef MYHEADER
    #define MYHEADER

    int** allocateMatrix(int n, int m);

    void inputMatrix (int **M, int n, int m);
    
    int matrixTimesK(int **M, int n, int m, int K);
    
    void printMatrix (int **M, int n, int m);
    
    int findMatrix(int **M, int n, int m, int me);
    
    int freeMatrix(int **M);
#endif
