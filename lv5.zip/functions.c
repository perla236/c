#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define max_number 250
#define minimum_number -1550



int** allocateMatrix(int n, int m) {
    int **M = calloc(n, sizeof(int*));
    int i;
    for (i = 0; i < n; i++) {
        M[i] = calloc(m, sizeof(int));
    }
    return M;
}
void inputMatrix(int **M, int n, int m) {
    int i, j; 
    srand(time(0));
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            M[i][j]= rand() % (max_number + 1 - minimum_number) + minimum_number;
        }
    }
    return;
}

int matrixTimesK(int **M, int n, int m, int K) {
    int i, j, sum[300], me;
    for(i=0;i<n;i++)
	 {
           m=m-1;
	   for(j=0;j<n ;j++)
            {
              if (j==m) 
                {
                  sum[i]= M[i][j];
                }
              
            }
	 }
	 
	 for(i=0;i<300;i++)
    {
        if(sum[i]%2!=0)
            continue;
        me=sum[i];
        break;
    }
    for(;i<n;i++)
    {
        if(sum[i]%2==0 && sum[i]>me)
            me=sum[i];
    }
    return me;
}

void printMatrix(int **M, int n, int m){
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            printf("%d\t",M[i][j]);
        }
        printf("\n");
    }
    return;
}

int freeMatrix(int **M){
    
    free(M);
       return 1; 
    
}
    
    
int findMatrix(int **M, int n, int m, int me){
    int i, j, x, y, z;
    int skup[300];
    
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            if(M[i][j]== me){
                x= i;
                y= j;
            }
            
            
        }
        
    }
    z=x;
    for(i=0; i<x; i++)
    {
        
        skup[i]=M[z][y];
        z--;
    }
        printf("\n");
    
    for(i=0; i<x; i++)
    {
        
        printf("%d, ", skup[i]);
    }
    
    return 0;
    
}


