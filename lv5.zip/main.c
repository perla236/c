#include "myheader.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    srand(time(0));
	int **M = NULL;
	int m, n, K, najveci;
	int skup[300];
	do
	{
	    n= rand() % (18 + 1 - 3) + 3;
}
    
    while (n<2 || n>19);
    m=n;
    
    //printf("Unesi k: ");
    //scanf("%d", &K);


	M = allocateMatrix(n, m);

	inputMatrix(M, n, m);

    najveci = matrixTimesK(M, n, m, K);

    printf("REZULTATI:\n");
    printMatrix(M, n, m);
    printf("\nNajveci parni je :%d", najveci);
    
    findMatrix(M, n, m, najveci);
    
    if (freeMatrix(M) == 1)
    printf("\nMemoryFree");
	return 0;
}

