#ifndef DATATYPE_H 

#define DATATYPE_H 


typedef struct clan
{
  unsigned int userID;
  char name[30];
  char surname[30];
  char adress[50];
  unsigned int phoneNum;
  int movieNum;


} MEMBER;

#endif //DATATYPE_H