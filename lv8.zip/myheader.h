//HEADER
#ifndef MYHEADER
    #define MYHEADER

#include "dataType.h"

int printMenu();
void newFile(const char* const fileName);
void addMember(const char* const fileName);
void* loadMember(const char* const fileName);
void printMember(const MEMBER* const memberArray);
    
#endif