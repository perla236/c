//MAIN
#include <stdio.h>
#include "myheader.h"
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include "dataType.h"



int main ()
{
    
    static MEMBER* memberArray = NULL;  
    static MEMBER* foundMember = NULL;
  int c;
  char yesno[2];
  char fileName[] = "clanovi.bin";
  newFile(fileName);
  do
    {
      printMenu ();
      scanf ("%d", &c);
      switch (c)
	{


	case 1:
	  system ("clear");
	  //FUNKCIJA
	  addMember(fileName);
	  printf ("\nUspjesno odradjeno\n");
	  c = 0;

	  break;



	case 2:
	  system ("clear");
	  //FUNKCIJA
	  loadMember(fileName);
	  printf ("\nUspjesno odradjeno\n");
	  c = 0;
	  break;



	case 3:
	  system ("clear");
	  //FUNKCIJA
	  printMember(memberArray);
	  printf ("\nUspjesno odradjeno\n");
	  c = 0;
	  break;



	case 4:
	  system ("clear");
	  //FUNKCIJA
	  printf ("\nUspjesno odradjeno\n");
	  c = 0;
	  break;



	case 5:
	  printf
	    ("Da li ste sigurni kako zelite zavrsiti program?\nDA/NE?\n");
	  getchar ();
	  scanf ("%2[^\n]", yesno);


	  if (!strcmp ("da", yesno))
	    {
	      printf ("Exiting the program....\n");
	      exit (0);
	    }

	  if (!strcmp ("Da", yesno))
	    {
	      printf ("Exiting the program....\n");
	      exit (0);
	    }

	  if (!strcmp ("dA", yesno))
	    {
	      printf ("Exiting the program....\n");
	      exit (0);
	    }

	  if (!strcmp ("DA", yesno))
	    {
	      printf ("Exiting the program....\n");
	      exit (0);
	    }

	  else
	    {
	      c = 0;
	    }

	default:
	  printf ("Out of range\n");

	  c = 0;
	  system ("clear");
	}

    }

  while (c > 1 || c < 6);
  return c;

  return 0;
}
