// FUNCTIONS
#include <stdio.h>
#include "myheader.h"
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include "dataType.h"


int printMenu()
{
    printf("====================");
printf("Odaberite jednu od ponudenih opcija:");
printf("====================\n");
printf("\tOpcija 1: Dodavanje novih članova u datoteku clanovi.bin\n");
printf("\tOpcija 2: Čitanje članova iz datoteke clanovi.bin.\n");
printf("\tOpcija 3: Ispisivanje podataka o svim korisnicima.bin\n");
printf("\tOpcija 4: Pretraži korisnika po ID-u i njegovo ispisivanje.\n");
printf("\tOpcija 5: Završetak programa. \n");
printf("======================================\
======================================\n");
return 0;
}

 static int numOfMembers = 0;


void newFile(const char* const fileName) 
{   
    FILE* pF = fopen(fileName, "wb");   
if (pF == NULL) {   
perror("Kreiranje datoteke clanovi.bin");   
exit(EXIT_FAILURE);  
    
} 

fwrite(&numOfMembers, sizeof(int), 1, pF);  
fclose(pF); 

}



void addMember(const char* const fileName)
{   
    FILE* pF = fopen(fileName, "rb+");   
    if (pF == NULL) {   
        perror("Dodavanje člana u datoteke clanovi.bin");   
        exit(EXIT_FAILURE);  
        
    }   
    
    fread(&numOfMembers, sizeof(int), 1, pF);  
    printf("numOfMembers: %d\n", numOfMembers);  
    MEMBER temp = { 0 };  
    temp.userID = numOfMembers;  
    getchar();  
    printf("Unesite ime clana!\n");  
    scanf("%29[^\n]", temp.name);  
    printf("Unesite prezime clana!\n");
    getchar();  
    scanf("%29[^\n]", temp.surname);
    printf("Unesite adresu clana!\n");
    getchar();  
    scanf("%49[^\n]", temp.adress);
    printf("Unesite mobilni telefon clana!\n");
    scanf("%ud", &temp.phoneNum);
    temp.movieNum = 0;
    printf("Unesite broj posuđenih filmova clana!\n");
    do 
    {
        printf("Broj moze biti od 0 do 4, molim unesite\nispravan broj posuđenih filmova clana!\n");
        scanf("%d", &temp.movieNum);
    }
    
    while(temp.movieNum < 0 || temp.movieNum > 5 );
    
    
    fseek(pF, sizeof(MEMBER) * numOfMembers, SEEK_CUR);  
    fwrite(&temp, sizeof(MEMBER), 1, pF);  
    rewind(pF);  numOfMembers++;  
    fwrite(&numOfMembers, sizeof(int), 1, pF);  
    fclose(pF); 
    
    
} 

void* loadMember(const char* const fileName) 
{   
    FILE* pF = fopen(fileName, "rb");   
    if (pF == NULL) 
    {   
        perror("Ucitavanje članova iz datoteke članovi.bin");   
        return NULL;   
        //exit(EXIT_FAILURE);  
        }   
        fread(&numOfMembers, sizeof(int), 1, pF);  
        printf("numOfMembers: %d\n", numOfMembers);  
        MEMBER* memberArray = (MEMBER*)calloc(numOfMembers, sizeof(MEMBER));   
        if (memberArray == NULL) {   
            perror("Zauzimanje memorije za članove");   
            return NULL;   
            //exit(EXIT_FAILURE);  
            }   
            fread(memberArray, sizeof(MEMBER), numOfMembers, pF);   
            
            return memberArray; } 



void printMember(const MEMBER* const memberArray) 
{   
    if (memberArray == NULL) 
    {   
        printf("Polje članova je prazno!\n");    
        return;  
        
    }   
    
    int i;  
    for (i = 0; i < numOfMembers; i++)  
    {   
        printf("Član broj %d\tID: %d\time: %s\tprezime: %s\nadresa: %s\nmobilni telefon: %ud\n broj filmova: %d\n\n\n",    i + 1,    (memberArray + i)->userID,    (memberArray + i)->name,    (memberArray + i)->surname, (memberArray + i)->adress, (memberArray + i)->phoneNum, (memberArray + i)->movieNum);
        } 
    
} 











/* int** menuChoice()
{
    char **c[2]=NULL;
    getchar();
    scanf("%2[^\n]", &c);
  }
*/