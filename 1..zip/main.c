#include <stdio.h>
#include <math.h>
typedef struct kompleksni
{ 
    float re;
    float im;
}KOMPLEKSNI;

KOMPLEKSNI br1;
KOMPLEKSNI br2;

typedef struct racun
{    
    float plus;
    float minus;
    float puta;
    float podjeljeno;
    float tmodul;
}RACUN;

float zbrajanje(float a, float b)
{
    float rez=a+b;
    return rez;
}

float oduzimanje(float a, float b)
{
    float rez=a-b;
    return rez;
}

float mnozenje(float a, float b)
{
    float rez=a*b;
    return rez;
}

float dijeljenjere(float a, float b, float c, float d)
{
    float rez=((a*c)+(b*d))/(pow(c,2)+pow(d,2));
    return rez;
}

float dijeljenjeim(float a, float b, float c, float d)
{
    float rez=((b*c)-(a*d))/(pow(c,2)+pow(d,2));
    return rez;
}

float modul(float a, float b)
{
    float rez=sqrt((pow(a,2)+pow(b,2)));
    return rez;
}

int main()
{
    printf("Unesite prvi kompleksni broj(a_bi)");
    scanf("%f %f", &br1.re,&br1.im);
    printf("\n");
    printf("Unesite drugi kompleksni broj(a_bi)");
    scanf("%f %f", &br2.re,&br2.im);
    printf("\n");
    
    RACUN realni;
    realni.plus=zbrajanje(br1.re,br2.re);
    realni.minus=oduzimanje(br1.re,br2.re);
    realni.puta=mnozenje(br1.re,br2.re) - mnozenje(br1.im,br2.im);
    realni.podjeljeno=dijeljenjere(br1.re,br1.im,br2.re,br2.im);
    realni.tmodul=modul(br1.re,br1.im);
    
    RACUN imaginarni;
    imaginarni.plus=zbrajanje(br1.im,br2.im);
    imaginarni.minus=oduzimanje(br1.im,br2.im);
    imaginarni.puta=mnozenje(br1.re,br2.im) + mnozenje(br1.im,br2.re);
    imaginarni.podjeljeno=dijeljenjeim(br1.re,br1.im,br2.re,br2.im);
    imaginarni.tmodul=modul(br2.re,br2.im);
    
    if(imaginarni.plus<0){
        printf("Zbroj je:%.2f  %.2fi", realni.plus, imaginarni.plus);
    }
    else{
        printf("Zbroj je:%.2f + %.2fi", realni.plus, imaginarni.plus);
    }
    printf("\n");
    
    if(imaginarni.minus<0){
        printf("Razlika je:%.2f  %.2fi", realni.minus, imaginarni.minus);
    }
    else{
        printf("Razlika je:%.2f + %.2fi", realni.minus, imaginarni.minus);
    }
    printf("\n");
    
    if(imaginarni.puta<0){
        printf("Umnozak je:%.2f  %.2fi", realni.puta, imaginarni.puta);
    }
    else{
        printf("Umnozak je:%.2f + %.2fi", realni.puta, imaginarni.puta);
    }
    printf("\n");
    
    if(imaginarni.podjeljeno<0){
        printf("Kvocjent je:%.2f  %.2fi", realni.podjeljeno, imaginarni.podjeljeno);
    }
    else{
        printf("Kvocjent je:%.2f + %.2fi", realni.podjeljeno, imaginarni.podjeljeno);
    }
    printf("\n");
    
    
    printf("Modul prvog broja je %.2f a drugog je %.2f", realni.tmodul, imaginarni.tmodul);
    
    
    return 0;
}
