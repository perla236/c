// FUNCTIONS
#include <stdio.h>
#include "myheader.h"
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include "dataType.h"
#include <unistd.h>
int printMenu()
{
    printf("\n");
printf("                          _.-=\"_-         _");
printf("\n                         _.-=\"   _-          | ||\"\"\"\"\"\"\"---._______     __..");
printf("\n             ___.===\"\"\"\"-.______-,,,,,,,,,,,,`-''----\" \"\"\"\"\"       \"\"\"\"\"  __'");
printf("\n      __.--\"\"     __        ,'LOVRO PERLIC SRVK1 o \\           __        [__|");
printf("\n __-\"\"=======.--\"\"  \"\"--.=================================.--\"\"  \"\"--.=======:");
printf("\n]       [w] : /        \\ : |========================|    : /        \\ :  [w] :");
printf("\nV___________:|          |: |========================|    :|          |:   _-\"");
printf("\n V__________: \\        / :_|=======================/_____: \\        / :__-\"");
printf("\n -----------'  \"-____-\"  `-------------------------------'  \"-____-\"\n");
printf(" [BORA GEDORA-KVIZ ANTIFRIZ]\n");
printf("====================");
printf("Odaberite jednu od ponudenih opcija:");
printf("====================\n");
printf("\tOpcija 1: POKRENI IGRU\n");
printf("\tOpcija 2: SCORE-OVI\n");
printf("\tOpcija 3: IZLAZ\n");
printf("======================================\
======================================\n");
return 0;
}




int printGear0()
{
    system ("clear");
    printf("1\t3\t5");
    printf("\n|\t|\t|\n|\t|\t|\n|\t|\t|\n");
    printf("--------O--------\n");
    printf("|\t|\t|\n|\t|\t|\n|\t|\t|\n");
    printf("2\t4\t6");
    return 0;
    
    
}

int printGear1()
{
    system ("clear");
    printf("1\t3\t5");
    printf("\nO\t|\t|\n|\t|\t|\n|\t|\t|\n");
    printf("-----------------\n");
    printf("|\t|\t|\n|\t|\t|\n|\t|\t|\n");
    printf("2\t4\t6");
    return 0;
    
}

int printGear2()
{
    system ("clear");
    printf("1\t3\t5");
    printf("\n|\t|\t|\n|\t|\t|\n|\t|\t|\n");
    printf("-----------------\n");
    printf("|\t|\t|\n|\t|\t|\nO\t|\t|\n");
    printf("2\t4\t6");
    return 0;
    
}

int printGear3()
{
    system ("clear");
    printf("1\t3\t5");
    printf("\n|\tO\t|\n|\t|\t|\n|\t|\t|\n");
    printf("-----------------\n");
    printf("|\t|\t|\n|\t|\t|\n|\t|\t|\n");
    printf("2\t4\t6");
    return 0;
    
}

int printGear4()
{   system ("clear");
    printf("1\t3\t5");
    printf("\n|\t|\t|\n|\t|\t|\n|\t|\t|\n");
    printf("-----------------\n");
    printf("|\t|\t|\n|\t|\t|\n|\tO\t|\n");
    printf("2\t4\t6");
    return 0;
    
}

int printGear5()
{
    system ("clear");
    printf("1\t3\t5");
    printf("\n|\t|\tO\n|\t|\t|\n|\t|\t|\n");
    printf("-----------------\n");
    printf("|\t|\t|\n|\t|\t|\n|\t|\t|\n");
    printf("2\t4\t6");
    return 0;
    
}

int printGear6()
{
    system ("clear");
    printf("1\t3\t5");
    printf("\n|\t|\t|\n|\t|\t|\n|\t|\t|\n");
    printf("-----------------\n");
    printf("|\t|\t|\n|\t|\t|\n|\t|\tO\n");
    printf("2\t4\t6");
    return 0;
    
}


int varYES(){

 int answer=0;
 char yesno[2];
	  getchar();
	  scanf ("%2[^\n]", yesno);

    if (!strcmp ("da", yesno)|| !strcmp ("Da", yesno) || !strcmp ("dA", yesno) || !strcmp ("DA", yesno) )
	    {
	      printf ("Odgovor je tocan\n");
	      answer++;
	      sleep(3);
	    }

	    else{
	    printf ("Odgovor je netocan\n");
	    answer=0;
	    sleep(3);
	    }
	    
	    return answer;
	    
}


int varNO(){

 int answer=0;
 char yesno[2];
	  getchar ();
	  scanf ("%2[^\n]", yesno);


	  if (!strcmp ("ne", yesno)|| !strcmp ("Ne", yesno) || !strcmp ("nE", yesno) || !strcmp ("NE", yesno) )
	    {
	      printf ("Odgovor je tocan\n");
	      answer++;
	      sleep(3);
	    }

	    else{
	    printf ("Odgovor je netocan\n");
	    answer=0;
	    sleep(3);
	    }
	    
	    return answer;
	    
}


int questRead(int lineNumber)
{
   FILE *quest;
   quest= fopen("dataQ.txt", "r");
   int count = 0;
   
    if ( quest != NULL )
    {   
    char questLine[256];
    while (fgets(questLine, sizeof questLine, quest) != NULL) 
        {   
            if (count == lineNumber)
            {   
                
            printf("\n%s ", questLine);
            fclose(quest);
            return 0;

            }   
            else
            {   
                count++;
            }   
           
        }
   
   fclose(quest);
    
    
    return 0;
}
}

char *playerReadName(int cp)
{
   FILE *scoreFile;
   scoreFile= fopen("scoreData.txt", "r");
   int count = 0;
   static char player[15];
    if ( scoreFile != NULL )
    {   
    char questLine[256];
    while (fgets(questLine, sizeof questLine, scoreFile) != NULL) 
        {   
            if (count == cp)
            {   
            strcpy(player, questLine);
            
            //printf("%s", player);
            //player[50] = questLine[256];
            fclose(scoreFile);
            return player;

            }   
            else
            {   
                count++;
            }   
           
        }
   
   fclose(scoreFile);
    
    
    return 0;
}
}




