//MAIN
#include <stdio.h>
#include "myheader.h"
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include "dataType.h"
#include <unistd.h>
int main()
{
    int c=0,c1=0;
    char yesno[2];
   int pointsCounter1=0, pointsCounter2=0, pointsCounter3=0;
    int pointsCounter4=0, pointsCounter5=0, pointsCounter6=0;
    int pointTime1=0, pointTime2=0, pointTime3=0, pointTime4=0;
    int pointTime5=0, pointTime6=0;
    int times1=0, times2=0, times3=0, times4=0, times5=0, times6=0;
    int pointTimeRes;
    int pointsCounterAll;
    PLAYER players[100];
    int tempi;
    int scores[100];
    int numplay;
  do
    {
      printMenu ();
      scanf ("%d", &c);
      switch (c)
	{

    
	case 1:
	  system ("clear");
////////////////////////////////////////////////////////////////////////////////////
FILE *scoreFile;
scoreFile= fopen("scoreData.txt", "r");
char cfile;
int countFile=0;
for (cfile = getc(scoreFile); cfile != EOF; cfile = getc(scoreFile)){
        if (cfile == '\n') 
            countFile = countFile + 1;
}
            
            countFile= (countFile+1)/2;
            int cp=0;
            int cp1=1;
            char tempchar[15];
        
        for(int i = 0; i<countFile; i++)
        {   
          
          strcpy(players[i].name, playerReadName(cp));
          strcpy(players[i].points, playerReadName(cp1));
          
          /*  printf("nesto");
         ///////////////////////////////////////////   
            FILE *scoreFile;
   scoreFile= fopen("scoreData.txt", "r");
   int count = 0;
   char player[50];
    if ( scoreFile != NULL )
    {   
    char questLine[256];
    while (fgets(questLine, sizeof questLine, scoreFile) != NULL) 
        {   
            if (count == cp)
            {   
            
            strcpy(players[i].name, questLine);
            printf("%s", players[i].name);
            
            }
            
            else
            {   
                count++;
            }   
            
        }
       
    
            //strcpy(tempchar, playerReadName(cp));
            //tempchar = playerReadName(cp);
            //players[i].name[15]=tempchar[15];
            //players[i].name = tempchar;
            //strcpy(players[i].name, tempchar);
            //players[i].points=playerReadPoints(cp+1);
            //playerReadName(cp, &tempchar);
            
            
        
             
        }
         */
         cp1=cp1+2;
        cp=cp+2;
    }
        
        fclose(scoreFile);
           /* printf("%d", countFile);
            printf("\n");
        for(int i= 0; i<countFile; i++){
            printf("\n");
        printf("%s", players[i].name);
        printf("\n");
printf("%s", players[i].points);
}

*/
//printf("%s", players[2].name);
printf("Unesite ime: ");
scanf("%s", players[countFile].name);


//imput player
///////////////////////////////////////////////////////////////////////////////////
	system ("clear");  
	  do
    {
        pointTimeRes=pointTime1+pointTime2+pointTime3+pointTime4+pointTime5+pointTime6;
      printGear0();
      
      printf("\nOdaberite brzinu: ");
      if (pointTimeRes !=6){
      scanf ("%d", &c1);
      }
      else
      c1=404;
      switch (c1)
      
	{
	  case 1:
	  times1++;
	  if(times1 <= 1) {
	      printGear1();
	    
	      questRead(1);
	      pointsCounter1=varYES()+pointsCounter1;
	     
	      questRead(2);
	      pointsCounter1=varYES()+pointsCounter1;
	     
	      questRead(3);
	      pointsCounter1=varNO()+pointsCounter1;
	      
	      questRead(4);
	      pointsCounter1=varNO()+pointsCounter1;
	      
	      questRead(5);
	      pointsCounter1=varNO()+pointsCounter1;
	      pointTime1++;
	      
	      c1 =0;
	         
	  }
	  else
	  
	  c1= 0;
	  break;
	  
	  
	  case 2:
	   times2++;
	  if(times2 <= 1) {
	      printGear2();
	      
	      questRead(8);
	      pointsCounter2=varNO()+pointsCounter2;
	     
	      questRead(9);
	      pointsCounter2=varNO()+pointsCounter2;
	     
	      questRead(10);
	      pointsCounter2=varYES()+pointsCounter2;
	      
	      questRead(11);
	      pointsCounter2=varYES()+pointsCounter2;
	      
	      questRead(12);
	      pointsCounter2=varYES()+pointsCounter2;
	      pointTime2++;
	      
	      c1 = 0;
	         
	  }
	  else
	  
	  
	  c1= 0;
	  break;
	  
	  
	  case 3:
	   times3++;
	  if(times3 <= 1) {
	      printGear3();
	      
	      questRead(15);
	      pointsCounter3=varYES()+pointsCounter3;
	     
	      questRead(16);
	      pointsCounter3=varYES()+pointsCounter3;
	     
	      questRead(17);
	      pointsCounter3=varNO()+pointsCounter3;
	      
	      questRead(18);
	      pointsCounter3=varYES()+pointsCounter3;
	      
	      questRead(19);
	      pointsCounter3=varNO()+pointsCounter3;
	      pointTime3++;
	      
	      c1 = 0;
	         
	  }
	  else
	  
	  c1= 0;
	  break;
	  
	  
	  case 4:
	   times4++;
	  if(times4 <= 1) {
	      printGear4();
	      
	      questRead(22);
	      pointsCounter4=varYES()+pointsCounter4;
	     
	      questRead(23);
	      pointsCounter4=varYES()+pointsCounter4;
	     
	      questRead(24);
	      pointsCounter4=varNO()+pointsCounter4;
	      
	      questRead(25);
	      pointsCounter4=varYES()+pointsCounter4;
	      
	      questRead(26);
	      pointsCounter4=varYES()+pointsCounter4;
	      pointTime4++;
	      
	      c1 = 0;
	         
	  }
	  else
	  
	  c1= 0;
	  break;
	  
	  
	  case 5:
	   times5++;
	  if(times5 <= 1) {
	      printGear5();
	      
	      questRead(31);
	      pointsCounter5=varNO()+pointsCounter5;
	     
	      questRead(32);
	      pointsCounter5=varYES()+pointsCounter5;
	     
	      questRead(33);
	      pointsCounter5=varYES()+pointsCounter5;
	      
	      questRead(34);
	      pointsCounter5=varNO()+pointsCounter5;
	      
	      questRead(35);
	      pointsCounter5=varYES()+pointsCounter5;
	      pointTime5++;
	      
	      c1 = 0;
	         
	  }
	  else
	  
	  c1= 0;
	  break;
	  
	  
	  case 6:
	   times6++;
	  if(times6 <= 1) {
	      printGear6();
	      
	      questRead(38);
	      pointsCounter6=varYES()+pointsCounter6;
	     
	      questRead(39);
	      pointsCounter6=varNO()+pointsCounter6;
	     
	      questRead(40);
	      pointsCounter6=varYES()+pointsCounter6;
	      
	      questRead(41);
	      pointsCounter6=varYES()+pointsCounter6;
	      
	      questRead(42);
	      pointsCounter6=varYES()+pointsCounter6;
	      pointTime6++;
	      
	      c1=0;
	  }
	      else
	  
	  c1= 0;
	  break;
	  
	  
	  case 404:
	  
	  system ("clear");
	  pointsCounterAll= pointsCounter1+pointsCounter2+pointsCounter3+pointsCounter4+pointsCounter5+pointsCounter6;
	  system ("clear");
	  printf("Vas rezultat je %d od 30 tocnih odgovora", pointsCounterAll);
	  //zapisivanje u rez.txt
	  
	  FILE *scoreFile;
    scoreFile= fopen("scoreData.txt", "a");
    fprintf(scoreFile, "\n%s", players[countFile].name);
   fprintf(scoreFile, "\n%d", pointsCounterAll);
   fclose(scoreFile);
   
	  sleep(5);
	  exit(0);
	  break;
	  
	  
	  default:
	  printf ("Out of range\n");

	  c1 = 0;
	  system ("clear");
	}
 
    }

  while (c1 < 1 || c1 > 7 || c1==404);
  return c1;
   
    
	  
        

////////////////////////////////////////////////////////////////////////////////////
	  
	  c = 0;
	  break;



	case 2:
	  system ("clear");
	  //FUNKCIJA
	  
	  
	  
scoreFile= fopen("scoreData.txt", "r");
cfile;
countFile=0;
for (cfile = getc(scoreFile); cfile != EOF; cfile = getc(scoreFile)){
        if (cfile == '\n') 
            countFile = countFile + 1;
}
            
            countFile= (countFile+1)/2;
             cp=0;
             cp1=1;
             tempchar[15];
        
   for(int i = 0; i<countFile; i++)
        {   
          
          strcpy(players[i].name, playerReadName(cp));
          strcpy(players[i].points, playerReadName(cp1));
          
          
         cp1=cp1+2;
        cp=cp+2;
    } 
    
    char tempSwitchName[15]; 
	 int points[100], tempSwitchPoints;
        for(int i= 0; i<countFile; i++){
        sscanf(players[i].points, "%d", &points[i]);
        }
	 
	  for(int i= 0; i<countFile+1; i++){
	      for(int j = 0; j<countFile+1; j++){
	      
	      if(points[j] < points[j+1]){
	      
	      
	      
	      tempSwitchPoints=points[j];
	     points[j]=points[j+1];
	     points[j+1]=tempSwitchPoints;
	      
	     strcpy(tempSwitchName, players[j].name);
	     strcpy(players[j].name, players[j+1].name);
	     strcpy(players[j+1].name, tempSwitchName);
	      }
	      }
	      
	  }
	  
	  
	 /* scoreFile= fopen("scoreData.txt", "w");
	  printf("scoreFiles, %s%d\n\n", players[i].name, points[i]);
	  fclose(scoreFile);
	 */ 
	  
	  for (int i= 0; i<countFile+1; i++){
	  printf("%s%d\n\n", players[i].name, points[i]);
	  }
	  
	  
	 
	  sleep(10);
	  system("clear");
	  c = 0;
	  break;




	case 3:
	  printf
	    ("Da li ste sigurni da zelite zavrsiti igricu?\nDA/NE?\n");
	  getchar ();
	  scanf ("%2[^\n]", yesno);


	  if (!strcmp ("da", yesno))
	    {
	      printf ("Exiting the program....\n");
	      exit (0);
	    }

	  if (!strcmp ("Da", yesno))
	    {
	      printf ("Exiting the program....\n");
	      exit (0);
	    }

	  if (!strcmp ("dA", yesno))
	    {
	      printf ("Exiting the program....\n");
	      exit (0);
	    }

	  if (!strcmp ("DA", yesno))
	    {
	      printf ("Exiting the program....\n");
	      exit (0);
	    }

	  else
	    {
	      c = 0;
	    }

	default:
	  printf ("Out of range\n");

	  c = 0;
	  system ("clear");
	}

    }

  while (c > 1 || c < 4);
  return c;

  return 0;
}
