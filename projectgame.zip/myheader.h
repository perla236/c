//HEADER
#ifndef MYHEADER
    #define MYHEADER

#include "dataType.h"
#include <unistd.h>
int printMenu();
int printGear0();
int printGear1();
int printGear2();
int printGear3();
int printGear4();
int printGear5();
int printGear6();
int varYES();
int varNO();
int questRead(int lineNumber);
char *playerReadName(int cp);


#endif