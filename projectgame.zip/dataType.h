#ifndef DATATYPE_H 

#define DATATYPE_H 


typedef struct 
{
  char name[15];
  char points[15];
  


}PLAYER;

#endif //DATATYPE_H