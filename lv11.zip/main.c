#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>


typedef struct student
{
    int id;
    char ime[20];
    char prezime[20];
    
}STUDENT;

STUDENT st[50];



int main()
{
    int n; 
    printf("Hello World");
    unosImenaPrezime(void);
    ispis(n);
   

    return 0;
}

unosImenaPrezime(void)
{
    int n;
    int i;
    FILE *otvori;
    otvori = fopen (studenti.txt, "w");
    if (otvori = NULL){
        
        fprintf(stderr, "\nGreska otvranja datoteke\n");
        exit(1);
        
        }
        
        printf("\nUpisi broj studenta:", i+1);
        scanf("%d", &n);
        
        for (i=0; i<n; i++){
            
            printf("\nUnesi ime %d studenta:");
            scanf("%19s, " st[i].ime);
            
            printf("\nUnesi prezime %d studenta:");
            scanf("%19s, " st[i].prezime);
        
            fprintf(otvori, "%s %s %d", st[i].ime, st[i].prezime, i);
            
        }
        
        
        for (i=0; i<n; i++){
            
            fscanf(otvori, "%s %s %d", st[i].ime, st[i].prezime, st[i].id);
            
            
        }
        
        if(fwrite != 0)
        printf("Zavrseno!");
        
        else
        printf("Greska");
        
        fclose(otvori);
}

ispis(void){
    
    FILE *citanje;
    char ch;
    
    citanje = fopen("studenti.txt", "r");
    
    if (citanje == NULL)
    printf("Dokument se ne moze otvoriti")
    
    
}


