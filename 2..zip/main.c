#include <stdio.h>

typedef struct
{
    unsigned short dan;
    unsigned short mjesec;
    unsigned short godina;
}DATUM;

typedef struct
{
    char ime[20];
    char prezime[20];
    short oib;
    float plata;
    DATUM rodj;
}PROGRAMER;

int main()
{
    int n;
    static int tempi;
    float templata1, templata2, templata;
    PROGRAMER programeri[15];
    
    do
    {
        printf("Unesi broj programera od 1 do 15: ");
        scanf("%d", &n);
        
    }
    while(n<1||n>15);
     
     for (int i = 0; i < n; i++)
{
    printf("Unesite ime %d. programera\n", i + 1);
    scanf("%19s", programeri[i].ime);
    
    printf("Unesite prezime %d. programera\n", i + 1);
    scanf("%19s", programeri[i].prezime);
    
    printf("Unesite OIB %d. programera\n", i + 1);
    scanf("%hi", &programeri[i].oib);
    
    printf("Unesite placu %d. programera\n", i + 1);
    scanf("%f", &programeri[i].plata);
    
    printf("Unesite dan rodjendana %d. programera\n", i + 1);
    scanf("%hu", &programeri[i].rodj.dan);
    
    printf("Unesite mjesec rodjendan %d. programera\n", i + 1);
    scanf("%hu", &programeri[i].rodj.mjesec);
    
    printf("Unesite godinu rodjendan %d. programera\n", i + 1);
    scanf("%hu", &programeri[i].rodj.godina);
    printf("\n");
    printf(" **************************************************");
    printf("\n");
    printf("Ime %d. programera: %s\n", i+1, programeri[i].ime);
    printf("Prezime %d. programera: %s\n", i+1, programeri[i].prezime);
    printf("OIB %d. programera: %d\n", i+1, programeri[i].oib);
    printf("Placa %d. programera: %f\n", i+1, programeri[i].plata);
    printf("Datum rodenja %d. programera: %2hu.%2hu.%4hu.\n", i+1, programeri[i].rodj.dan, programeri[i].rodj.mjesec, programeri[i].rodj.godina);
    printf(" **************************************************");
    printf("\n");
    }
    for(int i=0; i<n; i++)
    {
        if(programeri[i].plata>programeri[n-1].plata)
        {
            templata1=programeri[i].plata;
        }
        else {
            templata2=programeri[i].plata;
        }
    }
    if (templata1>templata2)
    {
        templata=templata1;
    }
    else
    {
        templata=templata2;
        
    }
    for (int i=0; i<n; i++)
    {
        if(templata==programeri[i].plata)
        {
            tempi=i;
            
            printf("\n Najvecu placu ima:\n");
    printf("Ime %d. programera: %s\n", tempi+1, programeri[tempi].ime);
    printf("Prezime %d. programera: %s\n", tempi+1, programeri[tempi].prezime);
    printf("OIB %d. programera: %d\n", tempi+1, programeri[tempi].oib);
    printf("Placa %d. programera: %f\n", tempi+1, programeri[tempi].plata);
    printf("Datum rodenja %d. programera: %2hu.%2hu.%4hu.\n", tempi+1, programeri[tempi].rodj.dan, programeri[tempi].rodj.mjesec, programeri[tempi].rodj.godina);
    
        }
    }
    
    
    return 0;
}
    


