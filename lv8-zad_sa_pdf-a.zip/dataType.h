#ifndef DATATYPE_H
#define DATATYPE_H
typedef struct student {
int id;
char ime[20];
char prezime[20];
}STUDENT;
#endif //DATATYPE_H