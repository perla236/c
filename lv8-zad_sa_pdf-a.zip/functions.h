#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include "dataType.h"
int izbornik(const char* const);
void kreiranjeDatoteke(const char* const);
void dodajStudenta(const char* const);
void* ucitavanjeStudenata(const char* const);
void ispisivanjeStudenata(const STUDENT* const);
void* pretrazivanjeStudenata(STUDENT* const);
void brisanjeStudenta(STUDENT** const, const STUDENT* const, const char* const);
void promjenaImenaDatoteci(const char*);
void brisanjeDatoteke(const char*);
int izlazIzPrograma(STUDENT*);
#endif //FUNCTIONS_H