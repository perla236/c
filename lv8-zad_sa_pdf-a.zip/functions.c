#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "dataType.h"
#include "functions.h"
int izbornik(const char* const imeDatoteke) {
printf("====================");
printf("Odaberite jednu od ponudenih opcija:");
printf("====================\n");
printf("\t\t\tOpcija 1: kreiranje datoteke!\n");
printf("\t\t\tOpcija 2: dodavanje studenta!\n");
printf("\t\t\tOpcija 3: ucitavanje studenata!\n");
printf("\t\t\tOpcija 4: ispisivanje studenata!\n");
printf("\t\t\tOpcija 5: pretrazivanje studenta!\n");
printf("\t\t\tOpcija 6: brisanje studenta!\n");
printf("\t\t\tOpcija 7: promjena imena datoteci!\n");
printf("\t\t\tOpcija 8: brisanje datoteke!\n");
printf("\t\t\tOpcija 9: izlaz iz programa!\n");
printf("======================================\
======================================\n");
int uvijet = 0;
static STUDENT* poljeStudenata = NULL;
static STUDENT* pronadeniStudent = NULL;
scanf("%d", &uvijet);
switch (uvijet) {
case 1:
kreiranjeDatoteke(imeDatoteke);
break;
case 2:
dodajStudenta(imeDatoteke);
break;
case 3:
if (poljeStudenata != NULL) {
free(poljeStudenata);
poljeStudenata = NULL;
}
poljeStudenata = (STUDENT*)ucitavanjeStudenata(imeDatoteke);
if (poljeStudenata == NULL) {
exit(EXIT_FAILURE);
}
break;
case 4:
ispisivanjeStudenata(poljeStudenata);
break;
case 5:
pronadeniStudent = (STUDENT*)pretrazivanjeStudenata(poljeStudenata);
break;
case 6:
brisanjeStudenta(&pronadeniStudent, poljeStudenata, imeDatoteke);
break;
case 7:
promjenaImenaDatoteci(imeDatoteke);
break;
case 8:
brisanjeDatoteke(imeDatoteke);
break;
case 9:
uvijet = izlazIzPrograma(poljeStudenata);
break;
default:
uvijet = 0;
}
return uvijet;
}

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dataType.h"
static int brojStudenata = 0;
void kreiranjeDatoteke(const char* const imeDatoteke) {
FILE* pF = fopen(imeDatoteke, "wb");
if (pF == NULL) {
perror("Kreiranje datoteke studenti.bin");
exit(EXIT_FAILURE);
}
fwrite(&brojStudenata, sizeof(int), 1, pF);
fclose(pF);
}
void dodajStudenta(const char* const imeDatoteke) {
FILE* pF = fopen(imeDatoteke, "rb+");
if (pF == NULL) {
perror("Dodavanje studenta u datoteke studenti.bin");
exit(EXIT_FAILURE);
}
fread(&brojStudenata, sizeof(int), 1, pF);
printf("brojStudenata: %d\n", brojStudenata);
STUDENT temp = { 0 };
temp.id = brojStudenata;
getchar();
printf("Unesite ime studenta!\n");
scanf("%19[^\n]", temp.ime);
printf("Unesite prezime studenta!\n");
getchar();
scanf("%19[^\n]", temp.prezime);
fseek(pF, sizeof(STUDENT) * brojStudenata, SEEK_CUR);
fwrite(&temp, sizeof(STUDENT), 1, pF);
rewind(pF);
brojStudenata++;
fwrite(&brojStudenata, sizeof(int), 1, pF);
fclose(pF);
}
void* ucitavanjeStudenata(const char* const imeDatoteke) {
FILE* pF = fopen(imeDatoteke, "rb");
if (pF == NULL) {
perror("Ucitavanje studenata iz datoteke studenti.bin");
return NULL;
//exit(EXIT_FAILURE);
}
fread(&brojStudenata, sizeof(int), 1, pF);
printf("brojStudenata: %d\n", brojStudenata);
STUDENT* poljeStudenata = (STUDENT*)calloc(brojStudenata, sizeof(STUDENT));
if (poljeStudenata == NULL) {
perror("Zauzimanje memorije za studente");
return NULL;
//exit(EXIT_FAILURE);
}
fread(poljeStudenata, sizeof(STUDENT), brojStudenata, pF);
return poljeStudenata;
}
void ispisivanjeStudenata(const STUDENT* const poljeStudenata) {
if (poljeStudenata == NULL) {
printf("Polje studenata je prazno!\n");
return;
}
int i;
for (i = 0; i < brojStudenata; i++)
{
printf("Student broj %d\tID: %d\time: %s\tprezime: %s\n",
i + 1,
(poljeStudenata + i)->id,
(poljeStudenata + i)->ime,
(poljeStudenata + i)->prezime);
}
}
void* pretrazivanjeStudenata(STUDENT* const poljeStudenata) {
if (poljeStudenata == NULL) {
printf("Polje studenata je prazno!\n");
return NULL;
}
int i;
char trazenoIme[20] = { '\0' };
printf("Unesite trazeni kriterij za pronalazak studenta.\n");
getchar();
scanf("%19[^\n]", trazenoIme);
for (i = 0; i < brojStudenata; i++)
{
if (!strcmp(trazenoIme, (poljeStudenata + i)->ime)) {
printf("Student je pronaden!\n");
return (poljeStudenata + i);
}
}
return NULL;
}
void promjenaImenaDatoteci(const char* staroImeDatoteke) {
char novoImeDatoteke[20] = { '\0' };
printf("Unesite novi naziv datoteke!\n");
getchar();
scanf("%19[^\n]", novoImeDatoteke);
printf("Zelite li uistinu promijeniti ime datoteci?\n");
printf("Utipkajte \"da\" ako uistinu želite promijeniti ime datoteke u suprotno utipkajte\"ne\"!\n");
char potvrda[3] = { '\0' };
scanf("%2s", potvrda);
if (!strcmp("da", potvrda)) {
rename(staroImeDatoteke, novoImeDatoteke) == 0 ?
printf("Uspjesno promijenjeno ime datoteci!\n") :
printf("Neuspjesno promijenjeno ime datoteci!\n");
}
}
void brisanjeStudenta(STUDENT** const trazeniStudent, const STUDENT* const poljeStudenata,
const char* const imeDatoteke) {
FILE* pF = fopen(imeDatoteke, "wb");
if (pF == NULL) {
perror("Brisanje studenta iz datoteke studenti.bin");
exit(EXIT_FAILURE);
}
fseek(pF, sizeof(int), SEEK_SET);
int i;
int noviBrojacStudenata = 0;
for (i = 0; i < brojStudenata; i++)
{
if (*trazeniStudent != (poljeStudenata + i)) {
fwrite((poljeStudenata + i), sizeof(STUDENT), 1, pF);
noviBrojacStudenata++;
}
}
rewind(pF);
fwrite(&noviBrojacStudenata, sizeof(int), 1, pF);
fclose(pF);
printf("Student je uspjesno obrisan!\n");
*trazeniStudent = NULL;
}
void brisanjeDatoteke(const char* imeDatoteke) {
printf("Zelite li uistinu obrisati datoteku %s?\n", imeDatoteke);
printf("Utipkajte \"da\" ako uistinu želite obrisati datoteku u suprotno utipkajte\
\"ne\"!\n");
char potvrda[3] = { '\0' };
scanf("%2s", potvrda);
if (!strcmp("da", potvrda)) {
remove(imeDatoteke) == 0 ? printf("Uspjesno obrisana datoteka %s!\n",
imeDatoteke) : printf("Neuspjesno brisanje datoteke %s!\n", imeDatoteke);
}
}
int izlazIzPrograma(STUDENT* poljeStudenata) {
free(poljeStudenata);
return 0;
}